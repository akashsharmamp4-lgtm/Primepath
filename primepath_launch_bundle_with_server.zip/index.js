// index.js - PrimePath Server
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import Razorpay from "razorpay";
import crypto from "crypto";
import bodyParser from "body-parser";
import admin from "firebase-admin";

dotenv.config();
const app = express();
app.use(cors());
app.use(bodyParser.json());

// ✅ Initialize Firebase
if (!admin.apps.length) {
  const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}
const db = admin.firestore();

// ✅ Initialize Razorpay
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

// ✅ Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "OK" });
});

// ➕ Create Razorpay Order
app.post("/api/create_order", async (req, res) => {
  try {
    const options = {
      amount: req.body.amount * 100, // amount in paise
      currency: "INR",
      receipt: `receipt_${Date.now()}`,
    };
    const order = await razorpay.orders.create(options);
    res.json(order);
  } catch (err) {
    console.error("Error creating order:", err);
    res.status(500).json({ error: "Failed to create order" });
  }
});

// ✅ Verify Razorpay Payment
app.post("/api/verify_payment", async (req, res) => {
  try {
    const { order_id, payment_id, signature } = req.body;
    const body = order_id + "|" + payment_id;
    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(body.toString())
      .digest("hex");

    if (expectedSignature === signature) {
      await db.collection("payments").add({
        order_id,
        payment_id,
        verified: true,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
      });
      return res.json({ success: true, message: "Payment verified" });
    } else {
      return res.status(400).json({ success: false, message: "Invalid signature" });
    }
  } catch (err) {
    console.error("Error verifying payment:", err);
    res.status(500).json({ error: "Payment verification failed" });
  }
});

// 📝 Save Lead Data
app.post("/api/leads", async (req, res) => {
  try {
    const { name, email, phone, source } = req.body;
    await db.collection("leads").add({
      name,
      email,
      phone,
      source,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    res.status(200).json({ success: true, message: "Lead saved" });
  } catch (error) {
    console.error("Error saving lead:", error);
    res.status(500).json({ success: false, message: "Failed to save lead" });
  }
});

// ✅ Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 PrimePath server running on port ${PORT}`);
});
